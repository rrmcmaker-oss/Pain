package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CurseForgeRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("X-Client", appName)
  }

  @Test
  fun `curseforge repository contains bundled packs`() {
    val repo = CurseForgeRepository()
    val addons = repo.getCuratedAddons()
    assertTrue(addons.isNotEmpty())
    val bundled = addons.filter { it.isDefaultBundle }
    assertEquals(3, bundled.size)
  }
}
