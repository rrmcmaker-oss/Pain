package com.example.data

import android.content.Context
import android.net.Uri
import com.example.model.InstalledPack
import java.io.File
import java.io.FileOutputStream

class PackManagerRepository(private val context: Context) {

    private val packsDir: File
        get() = File(context.filesDir, "minecraft_packs").apply { mkdirs() }

    fun getInstalledPacks(): List<InstalledPack> {
        val files = packsDir.listFiles() ?: return defaultPacksList()
        val list = mutableListOf<InstalledPack>()

        for (file in files) {
            val ext = file.extension.lowercase()
            val type = when (ext) {
                "mcpack" -> if (file.name.contains("RP", true) || file.name.contains("Resource", true)) "Resource Pack" else "Behavior Pack"
                "mcaddon" -> "Addon Bundle"
                else -> "Pack Archive"
            }
            list.add(
                InstalledPack(
                    id = file.name,
                    name = file.nameWithoutExtension.replace("_", " "),
                    type = type,
                    version = "v1.0",
                    fileName = file.name,
                    fileSizeFormatted = formatFileSize(file.length()),
                    isEnabled = true
                )
            )
        }

        return if (list.isEmpty()) defaultPacksList() else list
    }

    private fun defaultPacksList(): List<InstalledPack> {
        return listOf(
            InstalledPack(
                id = "xclient_crosshair_rp",
                name = "X-Client Crosshair RP",
                type = "Resource Pack (.mcpack)",
                version = "v0.8.0",
                fileName = "X_CLIENT_Crosshair_RP_v0.8.mcpack",
                fileSizeFormatted = "3.1 KB",
                isEnabled = true
            ),
            InstalledPack(
                id = "xclient_hud_bp",
                name = "X-Client HUD & PvP BP",
                type = "Behavior Pack (.mcpack)",
                version = "v0.8.0",
                fileName = "X_CLIENT_HUD_BP_v0.8.mcpack",
                fileSizeFormatted = "3.3 KB",
                isEnabled = true
            ),
            InstalledPack(
                id = "xclient_addons_suite",
                name = "X-Client Gameplay Addons",
                type = "Addon Bundle (.mcaddon)",
                version = "v0.8.0",
                fileName = "X_CLIENT_Gameplay_Addons_v0.8.mcaddon",
                fileSizeFormatted = "6.0 KB",
                isEnabled = true
            )
        )
    }

    fun importPackFromUri(uri: Uri, fileName: String): Result<File> {
        return try {
            val target = File(packsDir, fileName)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output)
                }
            } ?: return Result.failure(Exception("Cannot open file stream"))
            Result.success(target)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun deletePack(fileName: String): Boolean {
        val f = File(packsDir, fileName)
        return if (f.exists()) f.delete() else true
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
        return "%.1f %s".format(value, units[digitGroups.coerceIn(0, units.size - 1)])
    }
}
