package com.example.data

import com.example.model.AddonItem

class CurseForgeRepository {

    fun getCuratedAddons(): List<AddonItem> {
        return listOf(
            AddonItem(
                id = "xclient_crosshair_bundle",
                title = "X-Client Custom Crosshair RP",
                author = "X-Client Team",
                category = "Texture & RP",
                downloads = "142.5K",
                rating = 4.9f,
                description = "Neon high-precision PvP crosshairs engineered for competitive Minecraft Bedrock.",
                version = "v0.8.0",
                sizeString = "3.1 KB",
                assetFileName = "X_CLIENT_Crosshair_RP_v0.8.mcpack",
                isDefaultBundle = true,
                isInstalled = true
            ),
            AddonItem(
                id = "xclient_hud_bundle",
                title = "X-Client HUD & PvP Script Engine",
                author = "X-Client Team",
                category = "Script & HUD",
                downloads = "98.2K",
                rating = 5.0f,
                description = "Bedrock Script API gametest HUD showing real-time FPS, CPS, Keystrokes, Coordinates, and Armor Durability.",
                version = "v0.8.0",
                sizeString = "3.3 KB",
                assetFileName = "X_CLIENT_HUD_BP_v0.8.mcpack",
                isDefaultBundle = true,
                isInstalled = true
            ),
            AddonItem(
                id = "xclient_addon_combo",
                title = "X-Client All-in-One Gameplay Addon",
                author = "X-Client Team",
                category = "PvP & Combat",
                downloads = "210.8K",
                rating = 4.9f,
                description = "Complete bundled suite containing both custom crosshair resource pack and dynamic script behavior pack.",
                version = "v0.8.0",
                sizeString = "6.0 KB",
                assetFileName = "X_CLIENT_Gameplay_Addons_v0.8.mcaddon",
                isDefaultBundle = true,
                isInstalled = true
            ),
            AddonItem(
                id = "actions_stuff_pvp",
                title = "Actions & Stuff Animated PvP",
                author = "CrafterDevs",
                category = "PvP & Combat",
                downloads = "1.2M",
                rating = 4.8f,
                description = "Fluid combat animations, sword trails, sprinting dynamics, and combat feedback for Bedrock.",
                version = "v1.4.2",
                sizeString = "14.2 MB",
                isInstalled = false
            ),
            AddonItem(
                id = "bare_bones_pack",
                title = "Bare Bones Vibrant RP",
                author = "RobotPantaloons",
                category = "Texture & RP",
                downloads = "3.4M",
                rating = 4.9f,
                description = "The official trailer aesthetic! Simplifies textures for maximum FPS boost and ultra-clean visuals.",
                version = "v1.20",
                sizeString = "8.6 MB",
                isInstalled = false
            ),
            AddonItem(
                id = "damage_indicators",
                title = "Damage Indicators & Health Bars",
                author = "BedrockTools",
                category = "Script & HUD",
                downloads = "870K",
                rating = 4.7f,
                description = "Displays floating health indicators and critical damage numbers above mobs and players.",
                version = "v2.1.0",
                sizeString = "1.2 MB",
                isInstalled = false
            ),
            AddonItem(
                id = "definitive_clear_glass",
                title = "Definitive Seamless Clear Glass",
                author = "OptiCraft",
                category = "Texture & RP",
                downloads = "740K",
                rating = 4.8f,
                description = "Removes streaks from stained and regular glass for crystal-clear PvP vision.",
                version = "v3.0",
                sizeString = "450 KB",
                isInstalled = false
            ),
            AddonItem(
                id = "fast_bridge_helper",
                title = "Fast Bridging & Godbridge Assist",
                author = "HivePvpGuild",
                category = "PvP & Combat",
                downloads = "530K",
                rating = 4.6f,
                description = "Visual placement guides and edge collision cues to train ninja bridging and jump bridging.",
                version = "v1.1",
                sizeString = "920 KB",
                isInstalled = false
            ),
            AddonItem(
                id = "fullbright_night_vision",
                title = "Fullbright Gamma 250% Night Vision",
                author = "LunarMC",
                category = "Texture & RP",
                downloads = "1.9M",
                rating = 4.9f,
                description = "Permanent cave illumination and underwater visibility without needing potions or torches.",
                version = "v1.20",
                sizeString = "320 KB",
                isInstalled = false
            ),
            AddonItem(
                id = "defined_pbr_rtx",
                title = "Defined PBR Raytracing Lab",
                author = "MADLAD3718",
                category = "Visuals & Shaders",
                downloads = "410K",
                rating = 4.8f,
                description = "Ultra realistic physical specular & normal mapping for compatible devices and RTX displays.",
                version = "v1.1.8",
                sizeString = "38.5 MB",
                isInstalled = false
            )
        )
    }
}
