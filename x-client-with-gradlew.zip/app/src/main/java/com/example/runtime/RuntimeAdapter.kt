package com.example.runtime

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.model.ClientEngineStatus
import com.example.model.CrosshairConfig
import com.example.model.HudModule
import com.example.model.LaunchProfile
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class RuntimeAdapter(private val context: Context) {

    companion object {
        const val MINECRAFT_PACKAGE = "com.mojang.minecraftpe"
        const val LEVILAUNCHER_PACKAGE = "org.levimc.levilauncher"
    }

    fun getEngineStatus(activeProfile: LaunchProfile, activePackCount: Int): ClientEngineStatus {
        val isMcInstalled = isPackageInstalled(MINECRAFT_PACKAGE)
        val isLeviInstalled = isPackageInstalled(LEVILAUNCHER_PACKAGE)

        val detectedVersion = if (isMcInstalled) {
            try {
                val pInfo = context.packageManager.getPackageInfo(MINECRAFT_PACKAGE, 0)
                "v${pInfo.versionName ?: "1.20.80"}"
            } catch (e: Exception) {
                "v1.20.80 (Bedrock)"
            }
        } else {
            "Not Installed (Demo Mode)"
        }

        return ClientEngineStatus(
            isMinecraftInstalled = isMcInstalled,
            isLeviLauncherInstalled = isLeviInstalled,
            detectedVersion = detectedVersion,
            activeProfileName = activeProfile.name,
            activePackCount = activePackCount,
            currentFpsTarget = if (activeProfile.fpsLimit == 0) "Unlimited" else "${activeProfile.fpsLimit} FPS",
            nativeHookReady = isLeviInstalled || isMcInstalled
        )
    }

    fun isPackageInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Launches Minecraft Bedrock Edition or LeviLauncher
     */
    fun launchMinecraft(profile: LaunchProfile): Boolean {
        // First check LeviLauncher if installed, else Minecraft Bedrock
        val launchIntent = if (isPackageInstalled(LEVILAUNCHER_PACKAGE)) {
            context.packageManager.getLaunchIntentForPackage(LEVILAUNCHER_PACKAGE)
        } else {
            context.packageManager.getLaunchIntentForPackage(MINECRAFT_PACKAGE)
        }

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            // Attach simulation options
            launchIntent.putExtra("XCLIENT_PROFILE", profile.name)
            launchIntent.putExtra("XCLIENT_FPS", profile.fpsLimit)
            launchIntent.putExtra("XCLIENT_RES_SCALE", profile.resolutionScalePercent)
            context.startActivity(launchIntent)
            return true
        }

        return false
    }

    /**
     * Copies a default pack from assets to app external files dir and invokes
     * Minecraft Bedrock's pack importer via Intent.ACTION_VIEW
     */
    fun installPackToMinecraft(assetFileName: String): Result<File> {
        return try {
            val packsDir = File(context.filesDir, "minecraft_packs").apply { mkdirs() }
            val targetFile = File(packsDir, assetFileName)

            context.assets.open("default-packs/$assetFileName").use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }

            openPackWithMinecraft(targetFile)
            Result.success(targetFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Dispatches an Intent to import an .mcpack or .mcaddon into Minecraft
     */
    fun openPackWithMinecraft(file: File) {
        try {
            val authority = "${context.packageName}.provider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            // If Minecraft is installed, target it specifically; otherwise let Android chooser handle it
            if (isPackageInstalled(MINECRAFT_PACKAGE)) {
                intent.setPackage(MINECRAFT_PACKAGE)
            }

            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to generic chooser
            val authority = "${context.packageName}.provider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Open with Minecraft / File Manager").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    /**
     * Generates a dynamic .mcpack for the customized Crosshair on the fly!
     */
    fun exportCustomCrosshairPack(config: CrosshairConfig): File {
        val packsDir = File(context.filesDir, "generated_packs").apply { mkdirs() }
        val packFile = File(packsDir, "X_Client_Crosshair_${System.currentTimeMillis()}.mcpack")

        val manifestJson = """
        {
          "format_version": 2,
          "header": {
            "name": "§bX-Client §fCustom Crosshair §e[${config.type.displayName}]",
            "description": "Engineered with X-Client Crosshair Designer. Color: ${config.colorHex}",
            "uuid": "${UUID.randomUUID()}",
            "version": [1, 0, 0],
            "min_engine_version": [1, 20, 0]
          },
          "modules": [
            {
              "type": "resources",
              "uuid": "${UUID.randomUUID()}",
              "version": [1, 0, 0]
            }
          ]
        }
        """.trimIndent()

        ZipOutputStream(FileOutputStream(packFile)).use { zos ->
            // Add manifest
            zos.putNextEntry(ZipEntry("manifest.json"))
            zos.write(manifestJson.toByteArray())
            zos.closeEntry()

            // Copy crosshair texture from default or template
            zos.putNextEntry(ZipEntry("textures/ui/cross_hair.png"))
            try {
                // If template exists in default packs, extract texture or write basic PNG bytes
                val defRp = File(context.filesDir, "minecraft_packs/X_CLIENT_Crosshair_RP_v0.8.mcpack")
                if (defRp.exists()) {
                    java.util.zip.ZipFile(defRp).use { zf ->
                        val entry = zf.getEntry("textures/ui/cross_hair.png")
                        if (entry != null) {
                            zf.getInputStream(entry).copyTo(zos)
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore fallback
            }
            zos.closeEntry()
        }

        return packFile
    }

    /**
     * Generates a dynamic .mcpack for the customized HUD layout
     */
    fun exportCustomHudPack(modules: List<HudModule>): File {
        val packsDir = File(context.filesDir, "generated_packs").apply { mkdirs() }
        val packFile = File(packsDir, "X_Client_HUD_PvP_${System.currentTimeMillis()}.mcpack")

        val enabledNames = modules.filter { it.enabled }.joinToString(", ") { it.name }

        val scriptCode = """
        // X-Client Generated Bedrock Script Gametest
        // Active Modules: $enabledNames
        import { world, system } from "@minecraft/server";
        
        let clickHistory = [];
        system.runInterval(() => {
            for (const player of world.getAllPlayers()) {
                const loc = player.location;
                const x = Math.floor(loc.x);
                const y = Math.floor(loc.y);
                const z = Math.floor(loc.z);
                const now = Date.now();
                clickHistory = clickHistory.filter(t => now - t < 1000);
                const cps = clickHistory.length;
                
                player.onScreenDisplay.setActionBar(
                    `§b[X-CLIENT] §eXYZ: §f${'$'}{x}, ${'$'}{y}, ${'$'}{z} §8| §aCPS: §f${'$'}{cps} §8| §dFPS: §f120 §8| §6Modules: ${modules.count { it.enabled }}`
                );
            }
        }, 5);
        """.trimIndent()

        val manifestJson = """
        {
          "format_version": 2,
          "header": {
            "name": "§dX-Client §fPvP Custom HUD BP",
            "description": "Custom HUD layout with $enabledNames",
            "uuid": "${UUID.randomUUID()}",
            "version": [1, 0, 0],
            "min_engine_version": [1, 20, 0]
          },
          "modules": [
            {
              "type": "script",
              "language": "javascript",
              "uuid": "${UUID.randomUUID()}",
              "version": [1, 0, 0],
              "entry": "scripts/main.js"
            }
          ],
          "dependencies": [
            {
              "module_name": "@minecraft/server",
              "version": "1.8.0"
            }
          ]
        }
        """.trimIndent()

        ZipOutputStream(FileOutputStream(packFile)).use { zos ->
            zos.putNextEntry(ZipEntry("manifest.json"))
            zos.write(manifestJson.toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("scripts/main.js"))
            zos.write(scriptCode.toByteArray())
            zos.closeEntry()
        }

        return packFile
    }
}
