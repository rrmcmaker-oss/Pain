package com.example.model

data class LaunchProfile(
    val id: String,
    val name: String,
    val description: String,
    val category: String, // "Competitive PvP", "FPS Optimization", "Survival Plus", "RTX & Shaders"
    val fpsLimit: Int, // 60, 90, 120, 144, 240, 0 (unlimited)
    val memoryMb: Int, // 2048, 4096, 6144, 8192
    val fovMultiplier: Float, // 1.0f - 1.3f (Speed FOV)
    val resolutionScalePercent: Int, // 50 - 100%
    val vsync: Boolean,
    val antiAliasingLevel: Int, // 1, 2, 4
    val isDefault: Boolean = false
)

enum class HudCategory {
    COMBAT,
    NAVIGATION,
    PERFORMANCE,
    STATUS
}

data class HudModule(
    val id: String,
    val name: String,
    val category: HudCategory,
    val description: String,
    val enabled: Boolean,
    val posX: Float = 0.5f, // 0f..1f relative screen
    val posY: Float = 0.5f,
    val scale: Float = 1.0f,
    val opacity: Float = 0.9f,
    val colorHex: String = "#00F0FF",
    val showBackground: Boolean = true,
    val previewText: String = ""
)

enum class CrosshairType(val displayName: String) {
    CLASSIC_CROSS("Classic Cross"),
    DOT("Center Dot"),
    CIRCLE_CROSS("Circle Cross"),
    CHEVRON("Tactical Chevron"),
    DIAMOND("Diamond Reticle"),
    BOX("Square Box"),
    PLUS_DOT("Plus & Dot")
}

data class CrosshairConfig(
    val type: CrosshairType = CrosshairType.CLASSIC_CROSS,
    val size: Float = 14f, // 6..36
    val gap: Float = 5f, // 0..20
    val thickness: Float = 2.5f, // 1..8
    val dotSize: Float = 3f, // 0..8
    val colorHex: String = "#00F0FF",
    val opacity: Float = 1.0f,
    val hasOutline: Boolean = true,
    val outlineColorHex: String = "#000000",
    val rainbowChroma: Boolean = false,
    val dynamicRecoil: Boolean = true
)

data class AddonItem(
    val id: String,
    val title: String,
    val author: String,
    val category: String, // "PvP & Combat", "Texture & RP", "Script & HUD", "Visuals & Shaders"
    val downloads: String,
    val rating: Float,
    val description: String,
    val version: String,
    val sizeString: String,
    val assetFileName: String? = null,
    val isDefaultBundle: Boolean = false,
    val isInstalled: Boolean = false
)

data class InstalledPack(
    val id: String,
    val name: String,
    val type: String, // "Resource Pack (.mcpack)", "Behavior Pack (.mcpack)", "Addon Bundle (.mcaddon)"
    val version: String,
    val fileName: String,
    val fileSizeFormatted: String,
    val isEnabled: Boolean = true
)

data class ClientEngineStatus(
    val isMinecraftInstalled: Boolean,
    val isLeviLauncherInstalled: Boolean,
    val detectedVersion: String,
    val activeProfileName: String,
    val activePackCount: Int,
    val currentFpsTarget: String,
    val nativeHookReady: Boolean
)
