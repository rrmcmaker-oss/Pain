package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.FilterCenterFocus
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.RocketLaunch
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.ScreenTab
import com.example.ui.screens.AddonHubScreen
import com.example.ui.screens.CrosshairScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HudStudioScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(uiState.snackbarMessage) {
                    uiState.snackbarMessage?.let { msg ->
                        snackbarHostState.showSnackbar(
                            message = msg,
                            duration = SnackbarDuration.Short
                        )
                        viewModel.clearSnackbar()
                    }
                }

                // Handle back press: if not on DASHBOARD, return to DASHBOARD
                BackHandler(enabled = uiState.currentTab != ScreenTab.DASHBOARD) {
                    viewModel.selectTab(ScreenTab.DASHBOARD)
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DarkBackground,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        XClientBottomNavBar(
                            currentTab = uiState.currentTab,
                            onTabSelected = { viewModel.selectTab(it) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.currentTab) {
                            ScreenTab.DASHBOARD -> DashboardScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                            ScreenTab.HUD_STUDIO -> HudStudioScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                            ScreenTab.CROSSHAIR -> CrosshairScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                            ScreenTab.ADDONS -> AddonHubScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                            ScreenTab.SETTINGS -> SettingsScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun XClientBottomNavBar(
    currentTab: ScreenTab,
    onTabSelected: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .testTag("main_bottom_nav_bar"),
        containerColor = DarkSurface,
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        val navItems = listOf(
            NavigationItemData(
                tab = ScreenTab.DASHBOARD,
                label = "Launch",
                selectedIcon = Icons.Filled.RocketLaunch,
                unselectedIcon = Icons.Outlined.RocketLaunch,
                tag = "nav_tab_launch"
            ),
            NavigationItemData(
                tab = ScreenTab.HUD_STUDIO,
                label = "HUD & PvP",
                selectedIcon = Icons.Filled.GridView,
                unselectedIcon = Icons.Outlined.GridView,
                tag = "nav_tab_hud"
            ),
            NavigationItemData(
                tab = ScreenTab.CROSSHAIR,
                label = "Crosshairs",
                selectedIcon = Icons.Filled.FilterCenterFocus,
                unselectedIcon = Icons.Outlined.FilterCenterFocus,
                tag = "nav_tab_crosshair"
            ),
            NavigationItemData(
                tab = ScreenTab.ADDONS,
                label = "Addons",
                selectedIcon = Icons.Filled.Extension,
                unselectedIcon = Icons.Outlined.Extension,
                tag = "nav_tab_addons"
            ),
            NavigationItemData(
                tab = ScreenTab.SETTINGS,
                label = "Settings",
                selectedIcon = Icons.Filled.Settings,
                unselectedIcon = Icons.Outlined.Settings,
                tag = "nav_tab_settings"
            )
        )

        navItems.forEach { item ->
            val isSelected = currentTab == item.tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(item.tab) },
                icon = {
                    androidx.compose.material3.Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.label
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = DarkBackground,
                    selectedTextColor = CyberCyan,
                    indicatorColor = CyberCyan,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                ),
                modifier = Modifier.testTag(item.tag)
            )
        }
    }
}

data class NavigationItemData(
    val tab: ScreenTab,
    val label: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val tag: String
)
