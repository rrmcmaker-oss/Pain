package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CurseForgeRepository
import com.example.data.PackManagerRepository
import com.example.model.AddonItem
import com.example.model.ClientEngineStatus
import com.example.model.CrosshairConfig
import com.example.model.CrosshairType
import com.example.model.HudCategory
import com.example.model.HudModule
import com.example.model.InstalledPack
import com.example.model.LaunchProfile
import com.example.runtime.RuntimeAdapter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

enum class ScreenTab {
    DASHBOARD,
    HUD_STUDIO,
    CROSSHAIR,
    ADDONS,
    SETTINGS
}

data class ClientUiState(
    val currentTab: ScreenTab = ScreenTab.DASHBOARD,
    val profiles: List<LaunchProfile> = emptyList(),
    val activeProfile: LaunchProfile = LaunchProfile(
        id = "pvp_pro",
        name = "PvP Pro (120 FPS)",
        description = "Maximized frame rates, fast response, low latency VSync bypass",
        category = "Competitive PvP",
        fpsLimit = 120,
        memoryMb = 4096,
        fovMultiplier = 1.15f,
        resolutionScalePercent = 100,
        vsync = false,
        antiAliasingLevel = 1,
        isDefault = true
    ),
    val hudModules: List<HudModule> = emptyList(),
    val crosshairConfig: CrosshairConfig = CrosshairConfig(),
    val addons: List<AddonItem> = emptyList(),
    val installedPacks: List<InstalledPack> = emptyList(),
    val engineStatus: ClientEngineStatus = ClientEngineStatus(
        isMinecraftInstalled = false,
        isLeviLauncherInstalled = false,
        detectedVersion = "Checking…",
        activeProfileName = "PvP Pro",
        activePackCount = 3,
        currentFpsTarget = "120 FPS",
        nativeHookReady = true
    ),
    val liveCps: Int = 0,
    val totalTestClicks: Int = 0,
    val isTestingRecoil: Boolean = false,
    val snackbarMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val runtimeAdapter = RuntimeAdapter(application)
    private val curseForgeRepo = CurseForgeRepository()
    private val packRepo = PackManagerRepository(application)

    private val _uiState = MutableStateFlow(ClientUiState())
    val uiState: StateFlow<ClientUiState> = _uiState.asStateFlow()

    private val clickTimestamps = mutableListOf<Long>()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        val defaultProfiles = listOf(
            LaunchProfile(
                id = "pvp_pro",
                name = "PvP Pro (120 FPS)",
                description = "Lowest latency, aggressive texture caching, Bedwars & Hive tuned",
                category = "Competitive PvP",
                fpsLimit = 120,
                memoryMb = 4096,
                fovMultiplier = 1.15f,
                resolutionScalePercent = 100,
                vsync = false,
                antiAliasingLevel = 1,
                isDefault = true
            ),
            LaunchProfile(
                id = "fps_boost",
                name = "Ultra FPS Boost (Potato PC / Low-End)",
                description = "Maximum smoothness, disables heavy particles, 85% internal resolution",
                category = "FPS Optimization",
                fpsLimit = 240,
                memoryMb = 2048,
                fovMultiplier = 1.0f,
                resolutionScalePercent = 85,
                vsync = false,
                antiAliasingLevel = 1
            ),
            LaunchProfile(
                id = "vanilla_plus",
                name = "Vanilla+ Quality",
                description = "Crisp native resolution with 4x MSAA, full render distance",
                category = "Survival Plus",
                fpsLimit = 60,
                memoryMb = 4096,
                fovMultiplier = 1.0f,
                resolutionScalePercent = 100,
                vsync = true,
                antiAliasingLevel = 4
            ),
            LaunchProfile(
                id = "shaders_rtx",
                name = "PBR Shaders & High Fidelity",
                description = "Tuned for raytracing shaders, high render memory, cinematic lighting",
                category = "RTX & Shaders",
                fpsLimit = 90,
                memoryMb = 6144,
                fovMultiplier = 1.05f,
                resolutionScalePercent = 100,
                vsync = true,
                antiAliasingLevel = 2
            )
        )

        val defaultModules = listOf(
            HudModule(
                id = "fps_counter",
                name = "FPS Counter",
                category = HudCategory.PERFORMANCE,
                description = "Displays real-time frames per second and stability",
                enabled = true,
                posX = 0.05f,
                posY = 0.05f,
                previewText = "120 FPS"
            ),
            HudModule(
                id = "cps_counter",
                name = "CPS Counter (LMB / RMB)",
                category = HudCategory.COMBAT,
                description = "Tracks clicks per second for combat combos and jitter clicking",
                enabled = true,
                posX = 0.05f,
                posY = 0.12f,
                previewText = "CPS: 14.2 | 11.8"
            ),
            HudModule(
                id = "keystrokes",
                name = "Keystrokes Overlay",
                category = HudCategory.COMBAT,
                description = "Visual keyboard WASD, Space, and mouse clicks widget",
                enabled = true,
                posX = 0.82f,
                posY = 0.65f,
                previewText = "[W][A][S][D] [SPACE]"
            ),
            HudModule(
                id = "coordinates",
                name = "Coordinates & Direction",
                category = HudCategory.NAVIGATION,
                description = "Shows XYZ position, current biome, and compass orientation",
                enabled = true,
                posX = 0.05f,
                posY = 0.19f,
                previewText = "XYZ: 142, 64, -289 (S)"
            ),
            HudModule(
                id = "armor_durability",
                name = "Armor & Hand Status",
                category = HudCategory.STATUS,
                description = "Durability meters for helmet, chest, leggings, boots, and held weapon",
                enabled = true,
                posX = 0.85f,
                posY = 0.35f,
                previewText = "Diamond Set (92% Avg)"
            ),
            HudModule(
                id = "speedometer",
                name = "Speedometer (BPS)",
                category = HudCategory.NAVIGATION,
                description = "Measures sprint, fly, and horse velocity in Blocks Per Second",
                enabled = true,
                posX = 0.05f,
                posY = 0.26f,
                previewText = "7.84 BPS"
            ),
            HudModule(
                id = "ping_latency",
                name = "Ping / Server Latency",
                category = HudCategory.PERFORMANCE,
                description = "Server response time indicator with color-coded ping quality",
                enabled = true,
                posX = 0.85f,
                posY = 0.05f,
                previewText = "24 ms (Optimal)"
            ),
            HudModule(
                id = "combo_counter",
                name = "PvP Combo Counter",
                category = HudCategory.COMBAT,
                description = "Consecutive hits without taking damage in PvP fights",
                enabled = true,
                posX = 0.5f,
                posY = 0.35f,
                previewText = "Combo: 6 Hits"
            ),
            HudModule(
                id = "reach_display",
                name = "Hit Reach Distance",
                category = HudCategory.COMBAT,
                description = "Shows exact block distance on melee hits",
                enabled = false,
                posX = 0.5f,
                posY = 0.42f,
                previewText = "Reach: 2.98m"
            ),
            HudModule(
                id = "memory_monitor",
                name = "RAM / Memory Monitor",
                category = HudCategory.PERFORMANCE,
                description = "Current Bedrock runtime memory allocation",
                enabled = false,
                posX = 0.85f,
                posY = 0.12f,
                previewText = "RAM: 1.4 / 4.0 GB"
            )
        )

        val packs = packRepo.getInstalledPacks()
        val addons = curseForgeRepo.getCuratedAddons()
        val initialProfile = defaultProfiles.first()
        val engineStatus = runtimeAdapter.getEngineStatus(initialProfile, packs.size)

        _uiState.update {
            it.copy(
                profiles = defaultProfiles,
                activeProfile = initialProfile,
                hudModules = defaultModules,
                addons = addons,
                installedPacks = packs,
                engineStatus = engineStatus
            )
        }
    }

    fun selectTab(tab: ScreenTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun selectProfile(profile: LaunchProfile) {
        _uiState.update {
            it.copy(
                activeProfile = profile,
                engineStatus = runtimeAdapter.getEngineStatus(profile, it.installedPacks.size)
            )
        }
        showSnackbar("Profile activated: ${profile.name}")
    }

    fun updateProfileFps(fps: Int) {
        val updated = _uiState.value.activeProfile.copy(fpsLimit = fps)
        selectProfile(updated)
    }

    fun updateProfileResolution(res: Int) {
        val updated = _uiState.value.activeProfile.copy(resolutionScalePercent = res)
        selectProfile(updated)
    }

    fun updateProfileVsync(vsync: Boolean) {
        val updated = _uiState.value.activeProfile.copy(vsync = vsync)
        selectProfile(updated)
    }

    fun toggleHudModule(moduleId: String) {
        _uiState.update { state ->
            val updated = state.hudModules.map { mod ->
                if (mod.id == moduleId) mod.copy(enabled = !mod.enabled) else mod
            }
            state.copy(hudModules = updated)
        }
    }

    fun updateCrosshair(updater: (CrosshairConfig) -> CrosshairConfig) {
        _uiState.update { it.copy(crosshairConfig = updater(it.crosshairConfig)) }
    }

    fun selectCrosshairPreset(type: CrosshairType) {
        _uiState.update { state ->
            val newConfig = when (type) {
                CrosshairType.CLASSIC_CROSS -> CrosshairConfig(type = type, size = 14f, gap = 5f, thickness = 2.5f, dotSize = 0f, colorHex = "#00F0FF")
                CrosshairType.DOT -> CrosshairConfig(type = type, size = 6f, gap = 0f, thickness = 0f, dotSize = 4f, colorHex = "#10B981")
                CrosshairType.CIRCLE_CROSS -> CrosshairConfig(type = type, size = 16f, gap = 4f, thickness = 2f, dotSize = 2f, colorHex = "#A855F7")
                CrosshairType.CHEVRON -> CrosshairConfig(type = type, size = 18f, gap = 6f, thickness = 3f, dotSize = 0f, colorHex = "#F59E0B")
                CrosshairType.DIAMOND -> CrosshairConfig(type = type, size = 16f, gap = 4f, thickness = 2.5f, dotSize = 3f, colorHex = "#00F0FF")
                CrosshairType.BOX -> CrosshairConfig(type = type, size = 12f, gap = 2f, thickness = 2f, dotSize = 0f, colorHex = "#EF4444")
                CrosshairType.PLUS_DOT -> CrosshairConfig(type = type, size = 15f, gap = 6f, thickness = 2.5f, dotSize = 3f, colorHex = "#FFFFFF")
            }
            state.copy(crosshairConfig = newConfig)
        }
    }

    fun recordCpsClick() {
        val now = System.currentTimeMillis()
        clickTimestamps.add(now)
        val cutoff = now - 1000
        clickTimestamps.removeAll { it < cutoff }

        _uiState.update {
            it.copy(
                liveCps = clickTimestamps.size,
                totalTestClicks = it.totalTestClicks + 1,
                isTestingRecoil = true
            )
        }

        viewModelScope.launch {
            kotlinx.coroutines.delay(120)
            _uiState.update { it.copy(isTestingRecoil = false) }
        }
    }

    fun launchMinecraft(): Boolean {
        val profile = _uiState.value.activeProfile
        val launched = runtimeAdapter.launchMinecraft(profile)
        if (launched) {
            showSnackbar("Launching Minecraft Bedrock with ${profile.name}…")
        } else {
            showSnackbar("Minecraft Bedrock not detected. Packs & configs ready!")
        }
        return launched
    }

    fun installAddon(addon: AddonItem) {
        if (addon.assetFileName != null) {
            val result = runtimeAdapter.installPackToMinecraft(addon.assetFileName)
            if (result.isSuccess) {
                showSnackbar("Importing ${addon.title} into Minecraft Bedrock!")
                refreshInstalledPacks()
            } else {
                showSnackbar("Failed to unpack: ${result.exceptionOrNull()?.message}")
            }
        } else {
            // Emulate downloading community pack and preparing it
            showSnackbar("Downloaded ${addon.title}. Ready in Addon Hub!")
            _uiState.update { state ->
                val updatedAddons = state.addons.map {
                    if (it.id == addon.id) it.copy(isInstalled = true) else it
                }
                state.copy(addons = updatedAddons)
            }
        }
    }

    fun exportCustomCrosshairPack() {
        try {
            val pack = runtimeAdapter.exportCustomCrosshairPack(_uiState.value.crosshairConfig)
            runtimeAdapter.openPackWithMinecraft(pack)
            showSnackbar("Custom Crosshair Pack generated! Opening with Minecraft…")
            refreshInstalledPacks()
        } catch (e: Exception) {
            showSnackbar("Export error: ${e.message}")
        }
    }

    fun exportCustomHudPack() {
        try {
            val pack = runtimeAdapter.exportCustomHudPack(_uiState.value.hudModules)
            runtimeAdapter.openPackWithMinecraft(pack)
            showSnackbar("Custom HUD Behavior Pack generated! Opening with Minecraft…")
            refreshInstalledPacks()
        } catch (e: Exception) {
            showSnackbar("Export error: ${e.message}")
        }
    }

    fun importPackFromUri(uri: Uri, name: String) {
        val res = packRepo.importPackFromUri(uri, name)
        if (res.isSuccess) {
            val file = res.getOrThrow()
            runtimeAdapter.openPackWithMinecraft(file)
            showSnackbar("Imported $name successfully!")
            refreshInstalledPacks()
        } else {
            showSnackbar("Import failed: ${res.exceptionOrNull()?.message}")
        }
    }

    fun deleteInstalledPack(pack: InstalledPack) {
        packRepo.deletePack(pack.fileName)
        refreshInstalledPacks()
        showSnackbar("Removed ${pack.name}")
    }

    fun openInstalledPack(pack: InstalledPack) {
        val f = File(getApplication<Application>().filesDir, "minecraft_packs/${pack.fileName}")
        if (f.exists()) {
            runtimeAdapter.openPackWithMinecraft(f)
            showSnackbar("Launching ${pack.name} in Minecraft…")
        } else {
            // Try export or install default
            runtimeAdapter.installPackToMinecraft(pack.fileName)
        }
    }

    private fun refreshInstalledPacks() {
        val packs = packRepo.getInstalledPacks()
        _uiState.update {
            it.copy(
                installedPacks = packs,
                engineStatus = runtimeAdapter.getEngineStatus(it.activeProfile, packs.size)
            )
        }
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
