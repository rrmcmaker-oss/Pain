package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gaming Dark Theme Palette for X-Client
val CyberCyan = Color(0xFF00F0FF)
val CyberCyanDark = Color(0xFF00A3AD)
val NeonPurple = Color(0xFFA855F7)
val NeonPurpleDark = Color(0xFF7E22CE)
val EmeraldPvp = Color(0xFF10B981)
val CrimsonAlert = Color(0xFFEF4444)
val AmberGold = Color(0xFFF59E0B)

val DarkBackground = Color(0xFF0B0E17)
val DarkSurface = Color(0xFF131927)
val DarkSurfaceVariant = Color(0xFF1C2438)
val DarkSurfaceHighlight = Color(0xFF26314D)
val BorderSubtle = Color(0xFF2E3B5C)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val BedrockRed = Color(0xFFE11D48)
val BedrockDiamond = Color(0xFF38BDF8)
val BedrockGold = Color(0xFFFBBF24)
