package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.HudCategory
import com.example.model.HudModule
import com.example.ui.ClientUiState
import com.example.ui.MainViewModel
import com.example.ui.components.ArmorStatusOverlay
import com.example.ui.components.InteractiveKeystrokesWidget
import com.example.ui.theme.BedrockDiamond
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldPvp
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HudStudioScreen(
    viewModel: MainViewModel,
    uiState: ClientUiState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("hud_studio_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Title & Action
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "HUD & PVP STUDIO",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Configure on-screen telemetry, counters, and PvP widgets",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = { viewModel.exportCustomHudPack() },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonPurple,
                        contentColor = TextPrimary
                    ),
                    modifier = Modifier.testTag("export_hud_pack_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Export BP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Live Simulated Viewport Preview
        item {
            HudPreviewViewport(
                modules = uiState.hudModules,
                liveCps = uiState.liveCps,
                onClickTest = { viewModel.recordCpsClick() }
            )
        }

        // Category Groups
        HudCategory.values().forEach { category ->
            val modulesInCategory = uiState.hudModules.filter { it.category == category }
            if (modulesInCategory.isNotEmpty()) {
                item {
                    CategoryHeader(category = category)
                }
                items(modulesInCategory) { module ->
                    HudModuleItemCard(
                        module = module,
                        onToggle = { viewModel.toggleHudModule(module.id) }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun HudPreviewViewport(
    modules: List<HudModule>,
    liveCps: Int,
    onClickTest: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .testTag("hud_preview_viewport"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(NeonPurple, CyberCyan)))
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background Minecraft Scene
            Image(
                painter = painterResource(id = R.drawable.img_xclient_hero),
                contentDescription = "Minecraft Viewport",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dim overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBackground.copy(alpha = 0.5f))
            )

            // Top-Left Overlays (FPS, Ping, Coords, Speed)
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (modules.find { it.id == "fps_counter" }?.enabled == true) {
                    HudBadge(text = "120 FPS", color = EmeraldPvp)
                }
                if (modules.find { it.id == "ping_latency" }?.enabled == true) {
                    HudBadge(text = "24 ms (Optimal)", color = CyberCyan)
                }
                if (modules.find { it.id == "coordinates" }?.enabled == true) {
                    HudBadge(text = "XYZ: 142, 64, -289 (S)", color = BedrockDiamond)
                }
                if (modules.find { it.id == "speedometer" }?.enabled == true) {
                    HudBadge(text = "7.84 BPS", color = TextPrimary)
                }
            }

            // Top-Right Armor Overlay
            if (modules.find { it.id == "armor_durability" }?.enabled == true) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                ) {
                    ArmorStatusOverlay()
                }
            }

            // Center Combat Overlay
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(bottom = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (modules.find { it.id == "cps_counter" }?.enabled == true) {
                    HudBadge(
                        text = "CPS: $liveCps | 11.2",
                        color = CyberCyan
                    )
                }
                if (modules.find { it.id == "combo_counter" }?.enabled == true) {
                    HudBadge(
                        text = "Combo: 6 Hits",
                        color = NeonPurple
                    )
                }
            }

            // Bottom-Right Keystrokes
            if (modules.find { it.id == "keystrokes" }?.enabled == true) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                ) {
                    InteractiveKeystrokesWidget(
                        liveCps = liveCps,
                        onClickTest = onClickTest
                    )
                }
            }
        }
    }
}

@Composable
fun HudBadge(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = DarkBackground.copy(alpha = 0.8f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun CategoryHeader(category: HudCategory) {
    val (label, icon) = when (category) {
        HudCategory.COMBAT -> "COMBAT MODULES" to Icons.Default.SportsKabaddi
        HudCategory.NAVIGATION -> "NAVIGATION & MOVEMENT" to Icons.Default.Navigation
        HudCategory.PERFORMANCE -> "PERFORMANCE & ENGINE" to Icons.Default.Speed
        HudCategory.STATUS -> "STATUS & DURABILITY" to Icons.Default.Shield
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = CyberCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = CyberCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun HudModuleItemCard(
    module: HudModule,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hud_module_${module.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (module.enabled) DarkSurfaceHighlight else DarkSurface
        ),
        border = BorderStroke(
            1.dp,
            if (module.enabled) CyberCyan.copy(alpha = 0.7f) else BorderSubtle
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = module.name,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = module.previewText,
                            color = CyberCyan,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = module.description,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Switch(
                checked = module.enabled,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = CyberCyan,
                    checkedTrackColor = CyberCyan.copy(alpha = 0.3f),
                    uncheckedThumbColor = TextSecondary,
                    uncheckedTrackColor = DarkSurfaceVariant
                ),
                modifier = Modifier.testTag("switch_${module.id}")
            )
        }
    }
}
