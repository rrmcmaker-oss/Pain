package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CrosshairConfig
import com.example.model.CrosshairType
import com.example.ui.ClientUiState
import com.example.ui.MainViewModel
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldPvp
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CrosshairScreen(
    viewModel: MainViewModel,
    uiState: ClientUiState,
    modifier: Modifier = Modifier
) {
    val config = uiState.crosshairConfig

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("crosshair_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header & Export Action
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CROSSHAIR DESIGNER",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Build custom high-precision reticles for Bedrock",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = { viewModel.exportCustomCrosshairPack() },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = DarkBackground
                    ),
                    modifier = Modifier.testTag("export_crosshair_pack_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Export RP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Interactive Preview Viewport
        item {
            CrosshairInteractivePreview(
                config = config,
                isTestingRecoil = uiState.isTestingRecoil,
                onTestClick = { viewModel.recordCpsClick() }
            )
        }

        // Preset Reticles Carousel
        item {
            Column {
                Text(
                    text = "RETICLE PRESETS",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(CrosshairType.values()) { type ->
                        val isSelected = config.type == type
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectCrosshairPreset(type) },
                            color = if (isSelected) CyberCyan else DarkSurfaceVariant,
                            border = BorderStroke(1.dp, if (isSelected) CyberCyan else BorderSubtle)
                        ) {
                            Text(
                                text = type.displayName,
                                color = if (isSelected) DarkBackground else TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Customization Controls
        item {
            CrosshairSlidersCard(
                config = config,
                onChange = { updated -> viewModel.updateCrosshair { updated } }
            )
        }

        // Colors & Outline Card
        item {
            CrosshairColorCard(
                config = config,
                onChange = { updated -> viewModel.updateCrosshair { updated } }
            )
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun CrosshairInteractivePreview(
    config: CrosshairConfig,
    isTestingRecoil: Boolean,
    onTestClick: () -> Unit
) {
    var sceneIndex by remember { mutableStateOf(0) }
    val scenes = listOf("PvP Battle Arena", "Night Sky", "Deep Nether", "Grass Plain")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .testTag("crosshair_preview_box"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.5.dp, CyberCyan)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(onClick = onTestClick)
        ) {
            // Background Scene
            Image(
                painter = painterResource(id = R.drawable.img_xclient_hero),
                contentDescription = "Crosshair Preview Background",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dynamic Crosshair Canvas
            val recoilBloom by animateFloatAsState(
                targetValue = if (isTestingRecoil) 10f else 0f,
                label = "recoil_bloom"
            )

            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseColor = try {
                    Color(android.graphics.Color.parseColor(config.colorHex)).copy(alpha = config.opacity)
                } catch (e: Exception) {
                    CyberCyan
                }

                val armLength = config.size * 2f
                val gap = (config.gap * 2f) + recoilBloom
                val strokeW = config.thickness * 2f
                val dotR = config.dotSize * 1.5f

                // Draw Center Dot
                if (dotR > 0) {
                    if (config.hasOutline) {
                        drawCircle(Color.Black, radius = dotR + 2f, center = center)
                    }
                    drawCircle(baseColor, radius = dotR, center = center)
                }

                when (config.type) {
                    CrosshairType.CLASSIC_CROSS, CrosshairType.PLUS_DOT -> {
                        // Top, Bottom, Left, Right Arms
                        val lines = listOf(
                            Offset(center.x, center.y - gap - armLength) to Offset(center.x, center.y - gap),
                            Offset(center.x, center.y + gap) to Offset(center.x, center.y + gap + armLength),
                            Offset(center.x - gap - armLength, center.y) to Offset(center.x - gap, center.y),
                            Offset(center.x + gap, center.y) to Offset(center.x + gap + armLength, center.y)
                        )
                        lines.forEach { (start, end) ->
                            if (config.hasOutline) {
                                drawLine(Color.Black, start, end, strokeWidth = strokeW + 2f)
                            }
                            drawLine(baseColor, start, end, strokeWidth = strokeW)
                        }
                    }

                    CrosshairType.CIRCLE_CROSS -> {
                        val radius = gap + armLength / 2f
                        if (config.hasOutline) {
                            drawCircle(Color.Black, radius = radius, center = center, style = Stroke(strokeW + 2f))
                        }
                        drawCircle(baseColor, radius = radius, center = center, style = Stroke(strokeW))
                    }

                    CrosshairType.CHEVRON -> {
                        val path = Path().apply {
                            moveTo(center.x - gap - armLength, center.y + gap)
                            lineTo(center.x, center.y - gap)
                            lineTo(center.x + gap + armLength, center.y + gap)
                        }
                        if (config.hasOutline) {
                            drawPath(path, Color.Black, style = Stroke(strokeW + 2f))
                        }
                        drawPath(path, baseColor, style = Stroke(strokeW))
                    }

                    CrosshairType.DIAMOND -> {
                        val path = Path().apply {
                            moveTo(center.x, center.y - gap - armLength)
                            lineTo(center.x + gap + armLength, center.y)
                            lineTo(center.x, center.y + gap + armLength)
                            lineTo(center.x - gap - armLength, center.y)
                            close()
                        }
                        if (config.hasOutline) {
                            drawPath(path, Color.Black, style = Stroke(strokeW + 2f))
                        }
                        drawPath(path, baseColor, style = Stroke(strokeW))
                    }

                    CrosshairType.BOX -> {
                        val boxSize = (gap + armLength) * 2f
                        val topLeft = Offset(center.x - boxSize / 2f, center.y - boxSize / 2f)
                        if (config.hasOutline) {
                            drawRect(Color.Black, topLeft = topLeft, size = Size(boxSize, boxSize), style = Stroke(strokeW + 2f))
                        }
                        drawRect(baseColor, topLeft = topLeft, size = Size(boxSize, boxSize), style = Stroke(strokeW))
                    }

                    CrosshairType.DOT -> {
                        // Handled by dot draw
                    }
                }
            }

            // Bottom interactive hint
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(8.dp),
                shape = RoundedCornerShape(6.dp),
                color = DarkBackground.copy(alpha = 0.85f)
            ) {
                Text(
                    text = "TAP SCREEN TO TEST RECOIL & HIT EXPANSION",
                    color = CyberCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun CrosshairSlidersCard(
    config: CrosshairConfig,
    onChange: (CrosshairConfig) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("crosshair_sliders_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "GEOMETRY & SIZING",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            SliderRow(
                label = "SIZE",
                value = config.size,
                range = 4f..32f,
                display = "${config.size.toInt()} px",
                onChange = { onChange(config.copy(size = it)) }
            )

            SliderRow(
                label = "CENTER GAP",
                value = config.gap,
                range = 0f..20f,
                display = "${config.gap.toInt()} px",
                onChange = { onChange(config.copy(gap = it)) }
            )

            SliderRow(
                label = "THICKNESS",
                value = config.thickness,
                range = 1f..8f,
                display = "%.1f px".format(config.thickness),
                onChange = { onChange(config.copy(thickness = it)) }
            )

            SliderRow(
                label = "CENTER DOT",
                value = config.dotSize,
                range = 0f..8f,
                display = "${config.dotSize.toInt()} px",
                onChange = { onChange(config.copy(dotSize = it)) }
            )

            SliderRow(
                label = "OPACITY",
                value = config.opacity,
                range = 0.2f..1.0f,
                display = "${(config.opacity * 100).toInt()}%",
                onChange = { onChange(config.copy(opacity = it)) }
            )
        }
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: String,
    onChange: (Float) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Text(text = display, color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
    Slider(
        value = value,
        onValueChange = onChange,
        valueRange = range,
        colors = SliderDefaults.colors(
            thumbColor = CyberCyan,
            activeTrackColor = CyberCyan,
            inactiveTrackColor = DarkSurfaceHighlight
        )
    )
}

@Composable
fun CrosshairColorCard(
    config: CrosshairConfig,
    onChange: (CrosshairConfig) -> Unit
) {
    val palette = listOf(
        "#00F0FF" to "Cyan",
        "#A855F7" to "Purple",
        "#10B981" to "Emerald",
        "#F59E0B" to "Gold",
        "#EF4444" to "Crimson",
        "#FFFFFF" to "White"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("crosshair_color_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "COLOR & ACCENTS",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                palette.forEach { (hex, name) ->
                    val isSelected = config.colorHex.equals(hex, ignoreCase = true)
                    val col = Color(android.graphics.Color.parseColor(hex))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(col)
                            .border(
                                2.dp,
                                if (isSelected) TextPrimary else Color.Transparent,
                                CircleShape
                            )
                            .clickable { onChange(config.copy(colorHex = hex)) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Outline Contrast Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Black Contrast Outline",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Guarantees reticle visibility across snow & lava",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = config.hasOutline,
                    onCheckedChange = { onChange(config.copy(hasOutline = it)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberCyan,
                        checkedTrackColor = CyberCyan.copy(alpha = 0.3f),
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = DarkSurfaceHighlight
                    )
                )
            }
        }
    }
}
