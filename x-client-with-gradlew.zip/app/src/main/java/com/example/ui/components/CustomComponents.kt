package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClientEngineStatus
import com.example.model.LaunchProfile
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BedrockDiamond
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldPvp
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun XClientHeader(
    engineStatus: ClientEngineStatus,
    onLaunchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("xclient_header_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(CyberCyan, NeonPurple)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gamepad,
                            contentDescription = "X-Client Logo",
                            tint = DarkBackground,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "X-CLIENT",
                                color = TextPrimary,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = CyberCyan.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, CyberCyan)
                            ) {
                                Text(
                                    text = "v0.8 BEDROCK",
                                    color = CyberCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Next-Gen Minecraft Bedrock Utility & PvP Studio",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Status Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatusIndicatorChip(
                    label = "Bedrock",
                    value = if (engineStatus.isMinecraftInstalled) "Ready" else "Virtual",
                    isGood = engineStatus.isMinecraftInstalled
                )
                StatusIndicatorChip(
                    label = "LeviHook",
                    value = if (engineStatus.isLeviLauncherInstalled) "Active" else "Supported",
                    isGood = true
                )
                StatusIndicatorChip(
                    label = "FPS Mode",
                    value = engineStatus.currentFpsTarget,
                    isGood = true
                )
                StatusIndicatorChip(
                    label = "Packs",
                    value = "${engineStatus.activePackCount} Installed",
                    isGood = engineStatus.activePackCount > 0
                )
            }
        }
    }
}

@Composable
fun StatusIndicatorChip(
    label: String,
    value: String,
    isGood: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = DarkSurfaceVariant,
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (isGood) EmeraldPvp else AmberGold)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Column {
                Text(text = label, color = TextSecondary, fontSize = 9.sp)
                Text(
                    text = value,
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun InteractiveKeystrokesWidget(
    liveCps: Int,
    onClickTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isWPressed by remember { mutableStateOf(false) }
    var isAPressed by remember { mutableStateOf(false) }
    var isSPressed by remember { mutableStateOf(false) }
    var isDPressed by remember { mutableStateOf(false) }
    var isSpacePressed by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .testTag("keystrokes_widget"),
        shape = RoundedCornerShape(12.dp),
        color = DarkSurface.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // W Key
            KeyButton(label = "W", isPressed = isWPressed, onClick = { isWPressed = !isWPressed; onClickTest() })
            Spacer(modifier = Modifier.height(4.dp))
            // ASD Keys
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                KeyButton(label = "A", isPressed = isAPressed, onClick = { isAPressed = !isAPressed; onClickTest() })
                KeyButton(label = "S", isPressed = isSPressed, onClick = { isSPressed = !isSPressed; onClickTest() })
                KeyButton(label = "D", isPressed = isDPressed, onClick = { isDPressed = !isDPressed; onClickTest() })
            }
            Spacer(modifier = Modifier.height(4.dp))
            // Space / CPS Bar
            Surface(
                modifier = Modifier
                    .width(136.dp)
                    .height(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { isSpacePressed = !isSpacePressed; onClickTest() },
                color = if (isSpacePressed) CyberCyan else DarkSurfaceHighlight,
                border = BorderStroke(1.dp, if (isSpacePressed) CyberCyan else BorderSubtle)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "SPACE • $liveCps CPS",
                        color = if (isSpacePressed) DarkBackground else CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun KeyButton(
    label: String,
    isPressed: Boolean,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(if (isPressed) 0.92f else 1.0f, label = "key_scale")
    Surface(
        modifier = Modifier
            .size(42.dp)
            .scale(scale)
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        color = if (isPressed) CyberCyan else DarkSurfaceHighlight,
        border = BorderStroke(1.dp, if (isPressed) CyberCyan else BorderSubtle)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (isPressed) DarkBackground else TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun ArmorStatusOverlay(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = DarkSurface.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            ArmorPieceRow(piece = "Helmet", durability = "88%", color = BedrockDiamond)
            ArmorPieceRow(piece = "Chest", durability = "94%", color = BedrockDiamond)
            ArmorPieceRow(piece = "Leggings", durability = "76%", color = BedrockDiamond)
            ArmorPieceRow(piece = "Boots", durability = "82%", color = BedrockDiamond)
            ArmorPieceRow(piece = "Sword", durability = "Sharpness V", color = CyberCyan)
        }
    }
}

@Composable
fun ArmorPieceRow(piece: String, durability: String, color: Color) {
    Row(
        modifier = Modifier
            .width(120.dp)
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = piece, color = TextSecondary, fontSize = 10.sp)
        Text(text = durability, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
