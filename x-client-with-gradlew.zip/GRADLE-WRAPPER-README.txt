X-Client Gradle launcher
========================

Run ./gradlew tasks (Linux/macOS) or gradlew.bat tasks (Windows).
The launcher reads gradle/wrapper/gradle-wrapper.properties and downloads
the configured Gradle distribution on first run. Internet access is required
for the initial download. This is a lightweight bootstrap launcher and does
not include the official gradle-wrapper.jar.

Android builds also require a compatible JDK and Android SDK. For this project,
use JDK 17 or the JDK required by your Android Gradle Plugin setup.
