@echo off
setlocal
set "APP_HOME=%~dp0"
set "PROP=%APP_HOME%gradle\wrapper\gradle-wrapper.properties"
for /f "tokens=1,* delims==" %%A in ('findstr /b "distributionUrl=" "%PROP%"') do set "DIST_URL=%%B"
set "DIST_URL=%DIST_URL:\:=%"
for %%F in ("%DIST_URL%") do set "DIST_NAME=%%~nxF"
set "VERSION=%DIST_NAME:gradle-=%"
set "VERSION=%VERSION:-bin.zip=%"
set "VERSION=%VERSION:-all.zip=%"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "INSTALL_DIR=%GRADLE_USER_HOME%\wrapper\manual-dists\gradle-%VERSION%"
set "GRADLE_BIN=%INSTALL_DIR%\gradle-%VERSION%\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  echo Downloading Gradle %VERSION% ...
  if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%INSTALL_DIR%\%DIST_NAME%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%INSTALL_DIR%\%DIST_NAME%' '%INSTALL_DIR%'"
  if errorlevel 1 exit /b 1
  del "%INSTALL_DIR%\%DIST_NAME%"
)
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
